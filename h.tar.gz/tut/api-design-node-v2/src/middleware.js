import bodyParser from 'body-parser'

const setGlobalMiddleware = (app) => {
  
}

export default setGlobalMiddleware
