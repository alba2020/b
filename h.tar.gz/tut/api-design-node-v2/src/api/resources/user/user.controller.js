import { generateControllers } from '../../modules/query'
import { User } from './user.model'

export default generateControllers(User)
