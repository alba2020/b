import { generateControllers } from '../../modules/query'
import { Playlist } from './playlist.model'

export default generateControllers(Playlist)
