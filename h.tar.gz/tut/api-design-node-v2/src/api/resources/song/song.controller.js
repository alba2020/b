import { generateControllers } from '../../modules/query'
import { Song } from './song.model'

export default generateControllers(Song)
