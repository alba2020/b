# -*- coding: utf-8 -*-

from num2t4ru import num2text
t = num2text

# def t(p):
#     if p == 21:
#         return u"двадцать адын"
#     else:
#         return num2text(p)

# print t(100500)
# print t(2)
# print t(122101)

# t(21) <= t(1)
# t(1) == "один"
# t(21) == "двадцать адын"


digits = {
    1: u'один',
    2: u'два',
    3: u'три',
    4: u'четыре',
    5: u'пять',
    6: u'шесть',
    7: u'семь',
    8: u'восемь',
    9: u'девять'
}

number_10_19 = {
    10: u'десять',
    11: u'одиннадцать',
    12: u'двенадцать',
    13: u'тринадцать',
    14: u'четырнадцать',
    15: u'пятнадцать',
    16: u'шестнадцать',
    17: u'семнадцать',
    18: u'восемнадцать',
    19: u'девятнадцать'
}

number_tens = {
    20: u'двадцать',
    30: u'тридцать',
    40: u'сорок',
    50: u'пятьдесят',
    60: u'шестьдесят',
    70: u'семьдесят',
    80: u'восемьдесят',
    90: u'девяносто'
}

number_hundreds = {
    100: u'сто',
    200: u'двести',
    300: u'триста',
    400: u'четыреста',
    500: u'пятьсот',
    600: u'шестьсот',
    700: u'семьсот',
    800: u'восемьсот',
    900: u'девятьсот'
}

def test_zero(n, s):
    assert n == 0, "wrong argument"
    assert s == u"ноль", 'zero case'

def test_1_digit(n, s):
    assert 1 <= n <= 9
    assert s == digits[n], "wrong representation of number %d" % n

def test_2_digits(n, s):
    assert 1 <= n <= 99

    if 1 <= n <= 9:
        test_1_digit(n, s)
        return
    elif 10 <= n <= 19:
        assert s == number_10_19[n], "%d is not in [10, 19]" % n
        return

    tens, ones = n / 10, n % 10
    
    s_tens = s.split(' ')[0]
    # print tens
    # print s_tens
    assert s_tens == number_tens[tens * 10]

    if ones != 0:
        s_ones = s.split(' ')[1]
        test_1_digit(ones, s_ones)


def test_3_digits(n, s):
    assert 1 <= n <= 999

    if 1 <= n <= 99:
        test_2_digits(n, s)
        return

    hundreds, rest = n / 100, n % 100

    s_hundreds = s.split(' ')[0]

    # print s
    # print hundreds
    # print s_hundreds
    assert s_hundreds == number_hundreds[hundreds * 100]

    if rest > 0:
        s_rest = ' '.join(s.split(' ')[1:])
        test_2_digits(rest, s_rest)

def test_6_digits(n, s):
    first_triad, second_triad = n / 1000, n % 1000
    s_first_triad, s_second_triad = s.replace(u'тысяча', u'тысяч').replace(u'тысячи', u'тысяч').split(u'тысяч')
    s_second_triad = s_second_triad.strip()

    if second_triad > 0:
        test_3_digits(second_triad, s_second_triad)

# def test_3digits(p):
#     assert 100 <= p <= 999
#     hundreds, tens, ones = p / 100, p / 10 % 10, p % 10
#     if ones > 0


# def test(number, result):
#     assert t(number) == result, '%s case' % number
#     # if number == 0:
#     #     test_zero(number)

# def range():
#     test(0, u"ноль")

# def main():
#     range()

def make_test(number):
    if number == 0:
        test_zero(number, t(number))
    elif number >= 1 and number <= 9:
        test_1_digit(number, t(number))
    elif 10 <= number <= 99:
        test_2_digits(number, t(number))
    elif 100 <= number <= 999:
        test_3_digits(number, t(number))
    elif 1000 <= number <= 999999:
        test_6_digits(number, t(number))

# def make_test_1(number):
#     if number == 0:
#         test_zero(number)
#     for x in [number % 100, ((number % 100000) / 100) % 100, ((number  % 100000000) / 100000) % 100]:
#         if x >= 1 and x <= 9:
#             test_is_digit(x)
#         elif (10 <= x <= 19):
#             test_10_19(x)
#         elif 20 <= x <= 99:
#             test_2digits(x)
        
def main():
    return
    for i in range (10000): # 0 - 99
        print "test %d" % i
        make_test(i)
    # make_test(121125)

if __name__ == "__main__":
    main()

print t(1001)
make_test(1001)