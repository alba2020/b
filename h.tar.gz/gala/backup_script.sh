#!/bin/bash

MOUNT_POINT=/zoo
DIR=/home/alba/work
BACKUP_DIR=/zoo/backup
NAME=$(date '+%Y-%m-%d').tar.gz

do_backup() {
	echo "Backing up $DIR => $BACKUP_DIR"
	cd $DIR
	cd ..
	tar -czf /tmp/$NAME work
	mv /tmp/$NAME $BACKUP_DIR
}

delete_old_files() {
	echo "Deleting old files"
	find $BACKUP_DIR -mmin -60 -type f -print
	# find $BACKUP_DIR -mtime +30 -type f -delete
}

check_backup_directory_exists() {
	if [ ! -d "$BACKUP_DIR" ]; then
		echo "Error: Directory $BACKUP_DIR does not exist"
		exit
	fi
}

check_mount_point() {
	if ! mountpoint -q $MOUNT_POINT; then
		echo "Error: $MOUNT_POINT is not mounted"
		exit
	else
		echo "Mount point $MOUNT_POINT exists"
	fi
}

main() {
	check_mount_point
	check_backup_directory_exists
	do_backup
	delete_old_files
	echo "Done"
}

main
